**To delete a configuration document**

This example deletes the configuration document called ``Config_2``. If the command succeeds, no output is returned.

Command::

  aws ssm delete-document --name "Config_2"
